﻿namespace Admin_Login
{
    internal class openFileDialog
    {
    }
}