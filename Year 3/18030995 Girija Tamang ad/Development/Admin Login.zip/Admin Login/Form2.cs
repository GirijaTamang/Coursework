﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin_Login
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Import_Click(object sender, EventArgs e)
        {


        }
        private void datacsv(string filelocation)
        {
            DataTable dt = new DataTable();
            string[] lines = System.IO.File.ReadAllLines(filelocation);
            if (lines.Length > 0)
            {
                //firstline to create header
                string firstLine = lines[0];
                string[] headerLabels = firstLine.Split(',');
                foreach (string headerWord in headerLabels)
                {
                    dt.Columns.Add(new DataColumn(headerWord));
                }
                // for data 
                for (int r = 1; r <= lines.Length; r++)
                {
                    string[] dataWords = lines[r].Split(',');
                    DataRow dr = dt.NewRow();
                    int columnIndex = 0;
                    foreach (string headerword in headerLabels)
                    {
                        dr[headerword] = dataWords[columnIndex++];
                    }
                    dt.Rows.Add(dr);
                }
                if (dt.Rows.Count > 0)
                {
                    dataGridView1.DataSource = dt;
                }


            }
        }
        //declaring variable to store input
        String criteria;
        List<string> ctList = new List<string>();

        private void Criteria_Click(object sender, EventArgs e)
        {
            if (txtCriteria.Text == "")
            {
                MessageBox.Show("Please Insert Criteria information");
            }
            else
            {
                criteria = txtCriteria.Text;
                ctList.Add(criteria);
                MessageBox.Show("Criteria sucessfully added !!!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to user Feedback !!!", "Success",
            MessageBoxButtons.OK, MessageBoxIcon.Information);
            Form4 userForm = new Form4();
            userForm.Show();
            this.Hide();
            Form4 nf = new Form4();
            nf.receiveData(ctList);
            nf.Show();
        }



        public List<Feedback> LoadCSV(string csvFile)
        { 
            var query = from l in File.ReadAllLines(csvFile)
                let data = l.Split(',')
                select new Feedback
                {
                    name = data[0],
                    phone = int.Parse(data[1]),
                    email = data[2]

                };
            return query.ToList();
        }

        public class Feedback
        {

            public string name { get; set; }
            public int phone { get; set; }
            public string email { get; set; }

        }   

        private void button2_Click(object sender, EventArgs e)
        {
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "CSV File|*.csv";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    dataGridView1.Rows.Clear();
                    String[] lines = File.ReadAllLines(dialog.FileName);
                    String[] items;
                    lines.Skip(0);
                    bool fLine = true;
                    foreach (string line in lines)
                    {
                        items = line.Split(',');
                        if (fLine == true)
                        {
                            fLine = false;
                        }

                    }
                    MessageBox.Show("Data is Imported Successfully.");
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void load_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = LoadCSV(textBox1.Text);
        }

        private void browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.ShowDialog();
            textBox1.Text = dialog.FileName;
        }

        private void graph_Click(object sender, EventArgs e)
        {

        }
    }
}

