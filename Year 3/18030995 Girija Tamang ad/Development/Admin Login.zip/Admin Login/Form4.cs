﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin_Login
{
    public partial class Form4 : Form
    {
        ComboBox combo;

        public Form4()
        {
            InitializeComponent();

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
        public void receiveData(List<String> userInput)
        {
            uInput = userInput;
        }
        List<string> uInput = new List<String>();
        DataTable dt = new DataTable();
        private void Form4_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Critera", typeof(String));
            dt.Columns["Critera"].ReadOnly = true;
            foreach (String x in uInput)
            {
                dt.Rows.Add(x);
            }
            dataGridView1.DataSource = dt;

        }

        private void button1_Click(object sender, EventArgs e)
        { 
            
            using (StreamWriter sw = File.AppendText(@"D:\feedback.csv"))
            {   
                sw.WriteLine(fullname.Text + "," + dateTimePicker1.Text + "," + phoneNumber.Text + "," + email.Text );
                MessageBox.Show("Feedback Submitted");
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            combo = e.Control as ComboBox;
            if (combo != null)
            {
                combo.SelectedIndexChanged -= new EventHandler(combo_SelectedIndexChanged);
                combo.SelectedIndexChanged += combo_SelectedIndexChanged;

            }
        }

        private void combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = (sender as ComboBox).SelectedItem.ToString();
            MessageBox.Show(selected);
        }

        
        public class Feedbacks
        {

            public String fullname { get; set; }
            public int PhoneNumber { get; set; }
            public String EmailAddress { get; set; }
            public DateTime feedbackDate { get; set; }

        }

        //public Feedbacks(String fullname, int PhoneNumber, string EmailAddress, DateTime feedbackDate)
        //{
          //  SetFeedback(fullname, PhoneNumber, EmailAddress, feedbackDate);
        //}
        //public void SetStudent(string Name, int Phone, string Email, DateTime feedbackDate)
        //{

          //  this.fullname = Name;
            //this.phoneNumber = Phone;
            //this.EmailAddress = Email;
            //this.feedbackDate = feedbackDate;
        //}
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
            

