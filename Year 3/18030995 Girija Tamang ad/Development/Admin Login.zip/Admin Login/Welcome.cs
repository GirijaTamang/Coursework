﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin_Login
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 admin = new Form1();
            admin.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
         
            Form4 userFeed = new Form4();
            userFeed.Show();
            
        }

        private void Welcome_Load(object sender, EventArgs e)
        {

        }
    }
}
