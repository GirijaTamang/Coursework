﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Admin_Login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "admin")
            {
                MessageBox.Show("You have entered wrong username !!", "Alert",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox1.Clear();
            }
            else if (textBox2.Text != "admin")
            {
                MessageBox.Show("You have entered wrong password !!", "Alert",
               MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox2.Clear();
            }
            else
            {
                this.Hide();
                MessageBox.Show("Logged in Successfully !!!", "Success",
               MessageBoxButtons.OK, MessageBoxIcon.Information);
                 Form2 Admindash = new Form2();
                Admindash.Show();
                

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Welcome Admindash = new Welcome();
            Admindash.Show();
        }
    }
}
